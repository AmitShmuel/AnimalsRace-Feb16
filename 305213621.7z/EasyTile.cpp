#include "EasyTile.h"

void EasyTile::easyInformation() {
	
	cout << "EasyTile Information::\n"
		 << "Location: " << *this << endl 
		 <<	"Rabbit's cost: 0.5 , Turtle's cost: 0.75 , Frog's cost: 2\n";
}

