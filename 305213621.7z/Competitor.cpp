#include "Competitor.h"
#include "EasyTile.h"
#include "MediumTile.h"
#include "WaterTile.h"
#include "CropTile.h"
#include "EndTile.h"
#include "Rabbit.h"
#include "Frog.h"
#include "Turtle.h"
#include <typeinfo>

Competitor::Competitor(string s) : 
totalMovesCost(0) , name(s) , currentTile(new Tile(Point2D(-1,-1))) , prevTile(NULL) , allMoves(30) {

	//cout << "Cunstruct Competitor: " << s << "\n";
}



void Competitor::printInformation(Tile* t) {
	
	Tile& rt = *t;
	switch(t->getSign())
	{
		case '=':
			{
				try {
					
					EasyTile& et = dynamic_cast<EasyTile&>(rt);
					et.easyInformation();
				}
				
				catch(bad_cast& bc) 
				{
					cerr << "bad_cast caught: " << bc.what() << endl;
				}
				
				break;
			}
			
		case '#':
			{
				try {
					
					MediumTile& mt = dynamic_cast<MediumTile&>(rt);
					mt.mediumInformation();
				}
				
				catch(bad_cast& bc) 
				{
					cerr << "bad_cast caught: " << bc.what() << endl;
				}
				
				break;
			}
			
		case '~':
			{
				try {
					
					WaterTile& wt = dynamic_cast<WaterTile&>(rt);
					wt.waterInformation();
				}
				
				catch(bad_cast& bc) 
				{
					cerr << "bad_cast caught: " << bc.what() << endl;
				}
				
				break;
			}
			
		case 'v':
			{
				try {
					
					CropTile& ct = dynamic_cast<CropTile&>(rt);
					ct.cropInformation();
				}
				
				catch(bad_cast& bc) 
				{
					cerr << "bad_cast caught: " << bc.what() << endl;
				}
				
				break;
			}
			
		case 'E':
			{
				try {
					
					EndTile& endt = dynamic_cast<EndTile&>(rt);
					endt.endInformation();
				}
				
				catch(bad_cast& bc) 
				{
					cerr << "bad_cast caught: " << bc.what() << endl;
				}
				
				break;
			}
			
		default:
			{
				cout << "\nTile Information::\n"
		 		 << "Location: " << *t << endl 
		 		 <<	"Start point.. no cost is taken..\n";
			}
	}
}



void Competitor::printNoises() {
	
	if(getName() == "Rabbit")
	{
		try {
			
			Rabbit& pr = dynamic_cast<Rabbit&>(*this);
			pr.makeRabbitNoise();
		}
		
		catch(bad_cast& bc) 
		{
			cerr << "bad_cast caught: " << bc.what() << endl;
		}
	}
	
	else if(getName() == "Frog")
	{
		try {
			
			Frog& pf = dynamic_cast<Frog&>(*this);
			pf.makeFrogNoise();
		}
		
		catch(bad_cast& bc) 
		{
			cerr << "bad_cast caught: " << bc.what() << endl;
		}
	}
	
	else // Tuetle
	{
		try {
			
			Turtle& pt = dynamic_cast<Turtle&>(*this);
			pt.makeTurtleNoise();
		}
		
		catch(bad_cast& bc) 
		{
			cerr << "bad_cast caught: " << bc.what() << endl;
		}
	}
}



void Competitor::moveTo(Tile* t) {
	
	printInformation(t);
	prevTile = currentTile;
	currentTile = t; 
	allMoves.add(*t);
	t->onEnter(this); 
	printNoises();
}



Tile* Competitor::lookAhead(Tile***& track , int row , int col , Point2D target) {
	
	int i = currentTile->getPosX() , j = currentTile->getPosY();
	
	if(j < target.getCordY())
	{
		if(i==0)
		{
			if(prevTile->getPosX() == i+1 	&&	prevTile->getPosY() == j)
				moveTo(track[i][j+1]);
			else
				moveTo(cheapest(track[i][j+1] , track[i+1][j]));
		}
	
		else if(i==row-1)
		{
			if(prevTile->getPosX() == i-1 	&&	prevTile->getPosY() == j)
				moveTo(track[i][j+1]);
			else
				moveTo(cheapest(track[i][j+1] , track[i-1][j]));
		}
		
		else
		{
			if(prevTile->getPosX() == i+1 	&&	prevTile->getPosY() == j)
				moveTo(cheapest(track[i][j+1] , track[i-1][j]));
			else if(prevTile->getPosX() == i-1 	&&	prevTile->getPosY() == j)
				moveTo(cheapest(track[i][j+1] , track[i+1][j]));
			else
				moveTo(cheapest(cheapest(track[i][j+1] , track[i+1][j]) , track[i][j+1]));
		}
	}
	
	else if(j > target.getCordY())
	{
		if(i==0)
		{
			if(prevTile->getPosX() == i+1 	&&	prevTile->getPosY() == j)
				moveTo(track[i][j-1]);
			else
				moveTo(cheapest(track[i][j-1] , track[i+1][j]));
		}
		
		else if(i == row-1)
		{
			if(prevTile->getPosX() == i-1 	&&	prevTile->getPosY() == j)
				moveTo(track[i][j-1]);
			else
				moveTo(cheapest(track[i][j-1] , track[i-1][j]));
		}
		
		else
		{
			if(prevTile->getPosX() == i+1 	&&	prevTile->getPosY() == j)
				moveTo(cheapest(track[i][j-1] , track[i-1][j]));
			else if(prevTile->getPosX() == i-1 	&&	prevTile->getPosY() == j)
				moveTo(cheapest(track[i][j-1] , track[i+1][j]));
			else
				moveTo(cheapest(cheapest(track[i][j-1] , track[i+1][j]) , track[i-1][j]));
		}
	}

	else // j == targetj
	{
		if(target.getCordX() < i)
			moveTo(track[i-1][j]);
		else
			moveTo(track[i+1][j]);
	}
} 



void Competitor::printMoves(Tile*** track , int row , int col) {
	
	int i,j,k, count = allMoves.getCount();
	
	char** competitorMap = new char*[row];
	for(i=0;i<row;++i)
		competitorMap[i] = new char[col];
	
	for(i=0; i<row; ++i)
	{
		for(j=0;j<col;++j)
		{
			competitorMap[i][j] = ' ';
			if(track[i][j]->getType() == end)
				competitorMap[i][j] = 'E';
			
			for(k=0; k < count-1; ++k)
			{
				if(allMoves[k] == track[i][j])
				{
					competitorMap[i][j] = track[i][j]->getSign();
					break;
				}
			}
			if(track[i][j]->getType() == normal)
				competitorMap[i][j] = 'S';
		}
	}
	
	for(i=0;i<row;++i)
	{
		for(j=0;j<col;++j)
			cout << competitorMap[i][j] << " ";
		cout << endl;
	}
	
	for(i=0; i<row; ++i)
	{
		delete[] competitorMap[i];
		competitorMap[i] = NULL;
	}
		
	delete[] competitorMap;
	competitorMap = NULL;
}
