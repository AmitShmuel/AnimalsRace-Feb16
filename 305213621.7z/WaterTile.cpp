#include "WaterTile.h"

void WaterTile::waterInformation() {
	
	cout << "WaterTile Information::\n"
		 << "Location: " << *this << endl 
		 <<	"Rabbit's cost: 1 , Turtle's cost: 1 , Frog's cost: 0.5\n";
}

