#ifndef _DECLARE_
#define _DECLARE_
#include "Competitor.h"
#include "Tile.h"

#endif

