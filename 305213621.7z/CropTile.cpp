#include "CropTile.h"


void CropTile::cropInformation() {
	
	cout << "CropTile Information::\n"
		 << "Location: " << *this << endl 
		 <<	"Rabbit's cost: 2 , Turtle's cost: 1 , Frog's cost: 1\n";
}

