#include "EndTile.h"


void EndTile::endInformation() {
	
	cout << "EndTile Information::\n"
		 << "Location: " << *this << endl 
		 <<	"Finish point.. no cost is taken..\n";
}

